########################################
## Module 1
##
## Topics: 
    # Data gathering via API
    #  - URLs and GET
    # Cleaning and preparing text DATA
    # DTM and Data Frames
# much of the code was patterned after Dr. Gates' tutorials located at https://gatesboltonanalytics.com/
#########################################    

## What to import
import requests  ## for getting data from a server GET
import re   ## for regular expressions
import pandas as pd    ## for dataframes and related
from pandas import DataFrame

## To tokenize and vectorize text type data
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np

#word clouds
from wordcloud import WordCloud, STOPWORDS
import matplotlib.pyplot as plt

#stemming and lemming
import nltk
nltk.download('wordnet')
from nltk.stem import WordNetLemmatizer 
from nltk.stem.porter import PorterStemmer

# topics to query
topics=["cashless", "cashless society"]

## Create a new csv file to save the article descriptions
filename="NewsDataApi.csv"
MyFILE=open(filename,"w")  # "w"  for write

## Create a new txt file to save the raw newsapi.org jason data
filenametxt1="NewsApi.txt"
MyTxtFILE1=open(filenametxt1,"w")  # "w"  for write
MyTxtFILE1.write("raw newsapi.org jason data\n\n")
MyTxtFILE1.close()


## Create a new txt file to save the raw newsdata.io jason data
filenametxt2="NewsData.txt"
MyTxtFILE2=open(filenametxt2,"w")  # "w"  for write
MyTxtFILE2.write("raw newsdata.iojason data\n\n")
MyTxtFILE2.close()

### Place the column names in - write to the first row
WriteThis="LABEL,Date,Source,Title,Description\n"
MyFILE.write(WriteThis)
MyFILE.close()

endpoint="https://newsapi.org/v2/everything"
endpoint2="https://newsdata.io/api/1/news"

MaxArticles=100 #maximum number of articles

################# enter for loop to collect data on topics
for topic in topics:


    # connect to newsapi.org server
    counter = 0 #count the number of topics for newsapi.org
    URLPost = {'apiKey':'4ac9d1fb4397441c9e7856d4c620ba33',
               'q':topic
    }

    response=requests.get(endpoint, URLPost)
    print(response)
    jsontxt1 = response.json()
    #print(jsontxt1)
    
    MyTxtFILE1=open(filenametxt1,"a", encoding="utf-8")  # "a"  for append
    MyTxtFILE1.write(str(jsontxt1))
    MyTxtFILE1.close()

    # connect to newsdata.io server
    counter2 = 0 #count the number of topics for newsdata.io
    URLPost2 = {'apikey':'pub_16669aefee3fd802cfdd4a0edd68c997873cf',
               'q':topic
    }

    response2=requests.get(endpoint2, URLPost2)
    print(response2)
    jsontxt2 = response2.json()
    #print(jsontxt2)
        
    MyTxtFILE2=open(filenametxt2,"a", encoding="utf-8")  # "a"  for append
    MyTxtFILE2.write(str(jsontxt2))
    MyTxtFILE2.close()

    #####################################################
    
    LABEL=topic

    ## Open the NewsApi csv file for append and loop through articles
    MyFILE=open(filename, "a")
    for items in jsontxt1["articles"]:
        
        counter = counter + 1
        if(counter > MaxArticles):
            break #limit the number of articles to no more than MaxArticles

        print(items, "\n\n\n")
                  
        Source=items["source"]["id"]
        print(Source)
        
        Date=items["publishedAt"]
        ##clean up the date
        NewDate=Date.split("T")
        Date=NewDate[0]
        print(Date)
        
        ## CLEAN the Title
        ##----------------------------------------------------------
        ##Replace punctuation with space
        # Accept one or more copies of punctuation         
        # plus zero or more copies of a space
        # and replace it with a single space
        Title=items["title"]
        Title=str(Title)
        Title=re.sub(r'[,.;@#?!&$\-\']+', ' ', str(Title), flags=re.IGNORECASE)
        Title=re.sub(' +', ' ', str(Title), flags=re.IGNORECASE)
        Title=re.sub(r'\"', ' ', str(Title), flags=re.IGNORECASE)
        print(Title)
        # and replace it with a single space
        ## NOTE: Using the "^" on the inside of the [] means
        ## we want to look for any chars NOT a-z or A-Z and replace
        ## them with blank. This removes chars that should not be there.
        Title=re.sub(r'[^a-zA-Z0-9]', " ", str(Title), flags=re.VERBOSE)
        Title=Title.replace(',', '')
        Title=' '.join(Title.split())
        Title=re.sub("\n|\r", "", Title)


        #clean up description
        Headline=items["description"]
        Headline=str(Headline)
        #remove grabage characters
        Headline=re.sub(r'[,.;@#?!&$\-\']+', ' ', Headline, flags=re.IGNORECASE)
        Headline=re.sub(' +', ' ', Headline, flags=re.IGNORECASE)
        Headline=re.sub(r'\"', ' ', Headline, flags=re.IGNORECASE)
        Headline=re.sub(r'[^a-zA-Z0-9]', " ", Headline, flags=re.VERBOSE)
        ## Be sure there are no commas in the headlines or it will
        ## write poorly to a csv file....
        Headline=Headline.replace(',', '')
        Headline=' '.join(Headline.split())
        Headline=re.sub("\n|\r", "", Headline)
    
        print(Headline)



        #write to the csv file
        WriteThis=str(LABEL)+","+str(Date)+","+str(Source)+","+ str(Title) + "," + str(Headline) + "\n"
        print(WriteThis)
        
        #write to the csv file
        MyFILE.write(WriteThis)
        
    ## CLOSE THE CSV FILE
    MyFILE.close()
    ################## END for loop for newsapi.org #############################


 
    ## Open the NewsApi csv file for append and loop through articles
    MyFILE=open(filename, "a")
    for items in jsontxt2["results"]:
        
        counter2 = counter2 + 1
        if(counter2 > MaxArticles):
            break #limit the number of articles to no more than MaxArticles

        print(items, "\n\n\n")
                  
        Source=items["source_id"]
        print(Source)
        
        Date=items["pubDate"]
        ##clean up the date
        NewDate=Date.split(" ")
        Date=NewDate[0]
        print(Date)
        
        ## CLEAN the Title
        ##----------------------------------------------------------
        ##Replace punctuation with space
        # Accept one or more copies of punctuation         
        # plus zero or more copies of a space
        # and replace it with a single space
        Title=items["title"]
        Title=str(Title)
        Title=re.sub(r'[,.;@#?!&$\-\']+', ' ', str(Title), flags=re.IGNORECASE)
        Title=re.sub(' +', ' ', str(Title), flags=re.IGNORECASE)
        Title=re.sub(r'\"', ' ', str(Title), flags=re.IGNORECASE)
        print(Title)
        # and replace it with a single space
        ## NOTE: Using the "^" on the inside of the [] means
        ## we want to look for any chars NOT a-z or A-Z and replace
        ## them with blank. This removes chars that should not be there.
        Title=re.sub(r'[^a-zA-Z0-9]', " ", str(Title), flags=re.VERBOSE)
        Title=Title.replace(',', '')
        Title=' '.join(Title.split())
        Title=re.sub("\n|\r", "", Title)


        #clean up description
        Headline=items["description"]
        Headline=str(Headline)
        #remove grabage characters
        Headline=re.sub(r'[,.;@#?!&$\-\']+', ' ', Headline, flags=re.IGNORECASE)
        Headline=re.sub(' +', ' ', Headline, flags=re.IGNORECASE)
        Headline=re.sub(r'\"', ' ', Headline, flags=re.IGNORECASE)
        Headline=re.sub(r'[^a-zA-Z0-9]', " ", Headline, flags=re.VERBOSE)
        ## Be sure there are no commas in the headlines or it will
        ## write poorly to a csv file....
        Headline=Headline.replace(',', '')
        Headline=' '.join(Headline.split())
        Headline=re.sub("\n|\r", "", Headline)
    
        print(Headline)


        #write to the csv file
        WriteThis=str(LABEL)+","+str(Date)+","+str(Source)+","+ str(Title) + "," + str(Headline) +  "\n"
        print(WriteThis)
        
        #write to the csv file
        MyFILE.write(WriteThis)
        
    ## CLOSE THE CSV FILE
    MyFILE.close()
    ################## END for loop for newsdata.io #############################
    
################## END for loop for topics



#########################################################################################
##
##  Build labeled dataframes
##  convert the .csv file into labeled dataframes with 1000 columns
##  use CountVectorixer and TfidfVectorizer
##
#########################################################################################

My_DF=pd.read_csv(filename, error_bad_lines=False)

## Create the list of descriptions and labels
DescriptionLIST=[]
LabelLIST=[]

for nexthead, nextlabel in zip(My_DF["Description"], My_DF["LABEL"]):
    DescriptionLIST.append(nexthead)
    LabelLIST.append(nextlabel)

        
# remove all words smaller than 4 characters and larger than 10 characters
CleanedDescriptionLIST = []
for Headline in DescriptionLIST:
    Headline=str(Headline)
    Headline = ' '.join([wd for wd in Headline.split() if len(wd)>3 and len(wd)<11])
    CleanedDescriptionLIST.append(Headline)


        
# remove all words containing numbers
CleanedDescriptionLIST2 = []
for Headline in CleanedDescriptionLIST:
    Headline=str(Headline)
    Headline = ' '.join([wd for wd in Headline.split() if not any(char.isdigit() for char in wd)])
    CleanedDescriptionLIST2.append(Headline)

### Tokenize and Vectorize the Descriptions

### Vectorize
## Instantiate CV
MyCountV=CountVectorizer(
                        input="content",
                        stop_words = "english",
                        max_df=0.5, 
                        min_df=0.01,
                        max_features=100
                        )

MyCVDTM = MyCountV.fit_transform(CleanedDescriptionLIST2)  # create a sparse matrix

ColumnNames=MyCountV.get_feature_names()

## Build the CV data frame
MyCV_DF=pd.DataFrame(MyCVDTM.toarray(),columns=ColumnNames)

## Instantiate TFidf vectorizer
MyVect_TF=TfidfVectorizer(
                        input='content',
                        stop_words='english',
                        max_df=0.5, 
                        min_df=0.01,
                        max_features=100
                        )

MyTFDTM = MyVect_TF.fit_transform(CleanedDescriptionLIST2)  # create a sparse matrix

ColumnNames=MyVect_TF.get_feature_names()

## Build the TFidf data frame
MyTF_DF=pd.DataFrame(MyTFDTM.toarray(),columns=ColumnNames)

#add labels
######################################################

## Convert the labels from list to df
Labels_DF = DataFrame(LabelLIST,columns=['LABEL'])

## Create a complete and labeled dataframe
CVdfs = [Labels_DF, MyCV_DF]
TFdfs = [Labels_DF, MyTF_DF]

Final_News_CV_DF_Labeled = pd.concat(CVdfs,axis=1, join='inner')
Final_News_TF_DF_Labeled = pd.concat(TFdfs,axis=1, join='inner')

#print and write to csv the final dataframe
print(Final_News_TF_DF_Labeled)
Final_News_TF_DF_Labeled.to_csv("Final_News_TF_DF_Labeled.csv")

print(Final_News_CV_DF_Labeled)
Final_News_CV_DF_Labeled.to_csv("Final_News_CV_DF_Labeled.csv")


#---------------------------------------------------------
##
## Use Stemming and Lemming
##
##---------------------------------------------------------

LEMMER = WordNetLemmatizer() 

STEMMER=PorterStemmer()

# Use NLTK's PorterStemmer in a function
def MY_STEMMER(str_input):
    words = re.sub(r"[^A-Za-z\-]", " ", str_input).lower().split()
    words = [STEMMER.stem(word) for word in words]
    return words

def MY_LEMMER(str_input):
    words = re.sub(r"[^A-Za-z\-]", " ", str_input).lower().split()
    words = [LEMMER.lemmatize(word) for word in words]
    return words

MyVect_STEM=CountVectorizer(
                        input='content',
                        analyzer = 'word',
                        stop_words='english',
                        tokenizer=MY_STEMMER,
                        max_df=0.5, 
                        min_df=0.01, 
                        max_features=100
                        )

Vect_Stem = MyVect_STEM.fit_transform(CleanedDescriptionLIST2)
ColumnNames_s=MyVect_STEM.get_feature_names()
CorpusDF_Stem=pd.DataFrame(Vect_Stem.toarray(),columns=ColumnNames_s)
print(CorpusDF_Stem)


MyVect_LEM=CountVectorizer(
                        input='content',
                        analyzer = 'word',
                        stop_words='english',
                        tokenizer=MY_LEMMER,
                        max_df=0.5, 
                        min_df=0.01, 
                        max_features=100
                        )


Vect_LEM = MyVect_LEM.fit_transform(CleanedDescriptionLIST2)
ColumnNames_lem=MyVect_LEM.get_feature_names()
CorpusDF_LEM=pd.DataFrame(Vect_LEM.toarray(),columns=ColumnNames_lem)
print(CorpusDF_LEM)


#add labels
######################################################

## Create a complete and labeled dataframe
STEMdfs = [Labels_DF, CorpusDF_Stem]
LEMdfs = [Labels_DF, CorpusDF_LEM]

Final_News_CV_STEM_Labeled = pd.concat(STEMdfs,axis=1, join='inner')
Final_News_CV_LEM_Labeled = pd.concat(LEMdfs,axis=1, join='inner')

#print and write to csv the final dataframe
print(Final_News_CV_STEM_Labeled)
Final_News_CV_STEM_Labeled.to_csv("Final_News_CV_STEM_Labeled.csv")

print(Final_News_CV_LEM_Labeled)
Final_News_CV_LEM_Labeled.to_csv("Final_News_CV_LEM_Labeled.csv")


## Create the word clouds for each  of the topics. 
##--------------------------------------------------------
List_of_WC_CV=[]
List_of_WC_LEM=[]

for mytopic in topics:

    #original CV DF
    tempdfCV = Final_News_CV_DF_Labeled[Final_News_CV_DF_Labeled['LABEL'] == mytopic]
    
    tempdfCV =tempdfCV.sum(axis=0,numeric_only=True)
    NextVarNameCV=str("wc"+str(mytopic))

    ## Create and store in a list the wordcloud OBJECTS
    NextVarNameCV = WordCloud(width=1000, height=600, background_color="white",
                   min_word_length=4, #mask=next_image,
                   max_words=200).generate_from_frequencies(tempdfCV)
    
    List_of_WC_CV.append(NextVarNameCV)


    #Lemmatized DF
    tempdfLEM = Final_News_CV_LEM_Labeled[Final_News_CV_LEM_Labeled['LABEL'] == mytopic]
    
    tempdfLEM =tempdfLEM.sum(axis=0,numeric_only=True)
    NextVarNameLEM=str("wc"+str(mytopic))

    ## Create and store in a list the wordcloud OBJECTS
    NextVarNameLEM = WordCloud(width=1000, height=600, background_color="white",
                   min_word_length=4, #mask=next_image,
                   max_words=200).generate_from_frequencies(tempdfLEM)
    
    List_of_WC_LEM.append(NextVarNameLEM)
    

##------------------------------------------------------------------

########## Create the wordclouds
##########
fig1=plt.figure(figsize=(25, 25))
NumTopics=len(topics)
for i in range(NumTopics):
    print(i)
    ax = fig1.add_subplot(NumTopics,1,i+1)
    plt.imshow(List_of_WC_CV[i], interpolation='bilinear')
    plt.axis("off")
    plt.savefig("WordCloudCV.pdf")

fig2=plt.figure(figsize=(25, 25))
for i in range(NumTopics):
    print(i)
    ax = fig2.add_subplot(NumTopics,1,i+1)
    plt.imshow(List_of_WC_LEM[i], interpolation='bilinear')
    plt.axis("off")
    plt.savefig("WordCloudLEM.pdf")