########################################
## Module 1
##
## Topics: 
    # Data gathering via API
    #  - URLs and GET
    # Cleaning and preparing text DATA
    # DTM and Data Frames
# much of the code was patterned after Dr. Gates' tutorials located at https://gatesboltonanalytics.com/
#########################################    

## What to import
import requests  ## for getting data from a server GET
import re   ## for regular expressions
import pandas as pd    ## for dataframes and related
from pandas import DataFrame

## To tokenize and vectorize text type data
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np

#word clouds
from wordcloud import WordCloud, STOPWORDS
import matplotlib.pyplot as plt

#stemming and lemming
from nltk.stem import WordNetLemmatizer 
from nltk.stem.porter import PorterStemmer

from spellchecker import SpellChecker

spell = SpellChecker()

# neeed to pip install pyspellchecker
def check(word): #https://replit.com/talk/ask/How-to-check-if-a-word-is-an-English-word-with-Python/31374
    if word == spell.correction(word):
        return True
    else:
        return False
    
#########################################################################################
## webpage scraping
#########################################################################################

response = requests.get("https://www.ramseysolutions.com/budgeting/cashless-society")
print(response.text)
MyTXT=response.text

response = requests.get("https://sweden.se/life/society/a-cashless-society")
print(response.text)
MyTXT=MyTXT+response.text

response = requests.get("https://www.waldenu.edu/online-doctoral-programs/phd-in-public-policy-and-administration/resource/should-we-become-a-cashless-society")
print(response.text)
MyTXT=MyTXT+response.text

# save raw data
MyTxtFILE=open("RawScrapedData.txt","w", encoding="utf-8")  # "w"  for write
MyTxtFILE.write("raw scraped data\n\n")
MyTxtFILE.write(MyTXT)
MyTxtFILE.close()

## Create list
MyList=MyTXT.split(" ")
print(MyList)

MyVectLDA=CountVectorizer(input='content',
                        stop_words='english',
                        max_df=0.99, 
                        min_df=0.00001,
                        max_features=500)
data_vectorized = MyVectLDA.fit_transform(MyList)
ColumnNamesLDA=MyVectLDA.get_feature_names()

FinalDF=pd.DataFrame(data_vectorized.toarray(),columns=ColumnNamesLDA)
OriginalDF = FinalDF # save the original DF
OriginalDF.to_csv("OriginalDF.csv")

RemoveWords=["href", "class", "div", "block", "nav", "pagination", 
             "space", "https", "http", "template", "squarespace", "id", "jpg", "image","images",
             "header", "function", "folder", "font", "email", "fonts", "helvetica", "inline", "hidden",
             "footer", "format", "webkit"]

             

## Exmaple of how to remove certain words from your dataframe
## Removal can be using re - can be based on word length, etc

for nextcol in FinalDF.columns:
    if(re.search(r'[^A-Za-z]+', nextcol)): #drop non-letter words
        #print(nextcol)
        FinalDF=FinalDF.drop([nextcol], axis=1)
    elif(len(str(nextcol))<6): #drop short words
        print(nextcol)
        FinalDF=FinalDF.drop([nextcol], axis=1)
    elif(len(str(nextcol))>15): #drop long words
        print(nextcol)
        FinalDF=FinalDF.drop([nextcol], axis=1)
    elif(nextcol in RemoveWords): #drop RemoveWords
        print(nextcol)
        FinalDF=FinalDF.drop([nextcol], axis=1)
    elif(not check(nextcol)): #drop non-english words
        print(nextcol)
        FinalDF=FinalDF.drop([nextcol], axis=1)    
        
# Get the list of all column names from headers
column_names = FinalDF.columns.values.tolist()
print(column_names)
print(FinalDF)
# save the final DF
FinalDF.to_csv("FinalDF.csv")

##------------------------------------------------------------------

########## Create the wordclouds
tempdf = OriginalDF.sum(axis=0,numeric_only=True)
WC_original=WordCloud(width=1000, height=600, background_color="white",
               min_word_length=6, #mask=next_image,
               max_words=200).generate_from_frequencies(tempdf)   

tempdf = FinalDF.sum(axis=0,numeric_only=True)
WC_final=WordCloud(width=1000, height=600, background_color="white",
               min_word_length=6, #mask=next_image,
               max_words=200).generate_from_frequencies(tempdf)


########## Plot the wordclouds
fig1=plt.figure(figsize=(25, 25))
ax = fig1.add_subplot(2,1,1)
plt.imshow(WC_original, interpolation='bilinear')
plt.axis("off")
plt.savefig("WordCloud_WebScraping.pdf")
ax = fig1.add_subplot(2,1,2)
plt.imshow(WC_final, interpolation='bilinear')
plt.axis("off")
plt.savefig("WordCloud_WebScraping.pdf")

