####################################################
### Code patterned after the ARM with Twitter lecture: 
### https://gatesboltonanalytics.com/wp-content/uploads/2022/08/ARM-_with-Twitter_-Lecture-2021-Gates_Updated-2022.pptx
### Dr. Gates 
####################################################
library(viridis)
library(arules)
library(TSP)
library(data.table)
library(tcltk)
library(dplyr)
library(devtools)
library(purrr)
library(tidyr)
library(arulesViz)
library(stylo)
library(stringr)
library(readr)

CleanedTransactionFile="CleanedDescriptions.csv"
setwd("C:/Text_Mining/")

#read in the  transactions
Trans1 <- read.transactions(CleanedTransactionFile,format="basket",sep=",",skip=1)
inspect(Trans1)

##### Use apriori to get the RULES
Rules = arules::apriori(Trans1, parameter = list(support=.02, confidence=.25, minlen=2, maxlen=10))
(summary(Rules))

## Sort rules by a measure such as conf, sup, or lift
SortedRulesBySupport <- head(sort(Rules, by="support", decreasing=TRUE),15)
inspect(SortedRulesBySupport)
plot(SortedRulesBySupport, method="graph", engine="htmlwidget")

SortedRulesByConfidence <- head(sort(Rules, by="confidence", decreasing=TRUE),15)
inspect(SortedRulesByConfidence)
plot(SortedRulesByConfidence, method="graph", engine="htmlwidget")

SortedRulesByLift <- head(sort(Rules, by="lift", decreasing=TRUE),15)
inspect(SortedRulesByLift)
plot(SortedRulesByLift, method="graph", engine="htmlwidget")

