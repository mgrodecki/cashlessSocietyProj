####################################################
### Code patterned after: 
### Tutorial: Text Mining and NLP
### https://gatesboltonanalytics.com/?page_id=260
### Dr. Gates 
####################################################

library(ggplot2)
library(tm)
library(stringr)
library(wordcloud)
library(slam)
library(quanteda)
library(SnowballC)
library(arules)
library(proxy)
library(cluster)
library(stringi)
library(proxy)
library(Matrix)
library(tidytext) # convert DTM to DF
library(plyr) ## for adply
library(factoextra) # for fviz
library(mclust) # for Mclust EM clustering
library(gofastr)   ## for removing your own stopwords

library(textstem)  ## Needed for lemmatize_strings
library(amap)  ## for Kmeans
library(networkD3)


Datafile="Final_News_CV_STEM_No_Labels.csv"
setwd("C:/Text_Mining/")

# Import the data and look at it
Mydata <- read.csv(Datafile)
## remove column 1
Mydata <- Mydata[ ,-c(1) ]
head(Mydata)
nrow(Mydata)

############## Distance Measures ######################

m  <- Mydata
m_norm <- Mydata
distMatrix_E <- dist(m, method="euclidean")
print(distMatrix_E)
distMatrix_C <- dist(m, method="cosine")
print(distMatrix_C)


############# Clustering #############################
## Hierarchical

## Euclidean
groups_E <- hclust(distMatrix_E,method="ward.D")
plot(groups_E, cex=0.9, hang=-1, main = "Euclidean")
rect.hclust(groups_E, k=4)

## From the NetworkD3 library
radialNetwork(as.radialNetwork(groups_E))
dendroNetwork(groups_E)

## Cosine Similarity
groups_C <- hclust(distMatrix_C,method="ward.D")
plot(groups_C, cex=0.9, hang=-1,main = "Cosine Sim")
rect.hclust(groups_C, k=4)

radialNetwork(as.radialNetwork(groups_C))
dendroNetwork(groups_C)






####################   clustering -----------------------------


X <- m_norm

fviz_dist(distMatrix_C, gradient = list(low = "#00AFBB", 
                                             mid = "white", high = "#FC4E07"))+
  ggtitle("Cosine Sim Distance Map")

#-

distance0 <- get_dist(m_norm,method = "euclidean")
fviz_dist(distance0, gradient = list(low = "#00AFBB", 
                                     mid = "white", high = "#FC4E07"))+
  ggtitle("Euclidean Distance Map")



fviz_nbclust(Mydata, method = "silhouette", 
             FUN = hcut, k.max = 9)
