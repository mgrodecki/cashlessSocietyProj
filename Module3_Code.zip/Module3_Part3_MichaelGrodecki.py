########################################

## Module 3
##
## Topics: supervised learning methods: Naïve Bayes, Decision Trees, and SVMs

# much of the code was patterned after Dr. Gates' tutorials located at https://gatesboltonanalytics.com/
#########################################    

## What to import
import csv
import requests  ## for getting data from a server GET
import re   ## for regular expressions
import pandas as pd    ## for dataframes and related
from pandas import DataFrame

## To tokenize and vectorize text type data
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np

#word clouds
from wordcloud import WordCloud, STOPWORDS
import matplotlib.pyplot as plt

#stemming and lemming
from nltk.stem import WordNetLemmatizer 
from nltk.stem.porter import PorterStemmer

#LDA
from sklearn.decomposition import LatentDirichletAllocation 
import matplotlib.pyplot as plt
import numpy as np

#clustering, SVM, DT, MNB
from sklearn.metrics import silhouette_samples, silhouette_score
import sklearn
from sklearn.cluster import KMeans

from sklearn import preprocessing
from sklearn.preprocessing import LabelBinarizer

import seaborn as sns
from sklearn.metrics.pairwise import euclidean_distances
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.manifold import MDS
from mpl_toolkits.mplot3d import Axes3D
from scipy.cluster.hierarchy import ward, dendrogram

from sklearn.model_selection import train_test_split
import random as rd
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import confusion_matrix
from sklearn.svm import LinearSVC
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn import tree

## conda install python-graphviz
import graphviz



# topics to query
topics=["cashless", "cashless society", "virtual currency", "virtual money"]

## Create a new csv file to save the article descriptions
filename="NewsDataApi.csv"
MyFILE=open(filename,"w")  # "w"  for write

## Create a new txt file to save the raw newsapi.org jason data
filenametxt1="NewsApi.txt"
MyTxtFILE1=open(filenametxt1,"w")  # "w"  for write
MyTxtFILE1.write("raw newsapi.org jason data\n\n")
MyTxtFILE1.close()


## Create a new txt file to save the raw newsdata.io jason data
filenametxt2="NewsData.txt"
MyTxtFILE2=open(filenametxt2,"w")  # "w"  for write
MyTxtFILE2.write("raw newsdata.io jason data\n\n")
MyTxtFILE2.close()

### Place the column names in - write to the first row
WriteThis="LABEL,Date,Source,Title,Description\n"
MyFILE.write(WriteThis)
MyFILE.close()

endpoint="https://newsapi.org/v2/everything"
endpoint2="https://newsdata.io/api/1/news"

MaxArticles=200 #maximum number of articles

################# enter for loop to collect data on topics
for topic in topics:


    # connect to newsapi.org server
    counter = 0 #count the number of topics for newsapi.org
    URLPost = {'apiKey':'4ac9d1fb4397441c9e7856d4c620ba33',
               'q':topic
    }

    response=requests.get(endpoint, URLPost)
    print(response)
    jsontxt1 = response.json()
    #print(jsontxt1)
    
    MyTxtFILE1=open(filenametxt1,"a", encoding="utf-8")  # "a"  for append
    MyTxtFILE1.write(str(jsontxt1))
    MyTxtFILE1.close()

    # connect to newsdata.io server
    counter2 = 0 #count the number of topics for newsdata.io
    URLPost2 = {'apikey':'pub_16669aefee3fd802cfdd4a0edd68c997873cf',
               'q':topic
    }

    response2=requests.get(endpoint2, URLPost2)
    print(response2)
    jsontxt2 = response2.json()
    #print(jsontxt2)
        
    MyTxtFILE2=open(filenametxt2,"a", encoding="utf-8")  # "a"  for append
    MyTxtFILE2.write(str(jsontxt2))
    MyTxtFILE2.close()

    #####################################################
    
    LABEL=topic

    ## Open the NewsApi csv file for append and loop through articles
    MyFILE=open(filename, "a")
    for items in jsontxt1["articles"]:
        
        counter = counter + 1
        if(counter > MaxArticles):
            break #limit the number of articles to no more than MaxArticles

        print(items, "\n\n\n")
                  
        Source=items["source"]["id"]
        print(Source)
        
        Date=items["publishedAt"]
        ##clean up the date
        NewDate=Date.split("T")
        Date=NewDate[0]
        print(Date)
        
        ## CLEAN the Title
        ##----------------------------------------------------------
        ##Replace punctuation with space
        # Accept one or more copies of punctuation         
        # plus zero or more copies of a space
        # and replace it with a single space
        Title=items["title"]
        Title=str(Title)
        Title=re.sub(r'[,.;@#?!&$\-\']+', ' ', str(Title), flags=re.IGNORECASE)
        Title=re.sub(' +', ' ', str(Title), flags=re.IGNORECASE)
        Title=re.sub(r'\"', ' ', str(Title), flags=re.IGNORECASE)
        print(Title)
        # and replace it with a single space
        ## NOTE: Using the "^" on the inside of the [] means
        ## we want to look for any chars NOT a-z or A-Z and replace
        ## them with blank. This removes chars that should not be there.
        Title=re.sub(r'[^a-zA-Z0-9]', " ", str(Title), flags=re.VERBOSE)
        Title=Title.replace(',', '')
        Title=' '.join(Title.split())
        Title=re.sub("\n|\r", "", Title)


        #clean up description
        Headline=items["description"]
        Headline=str(Headline)
        #remove grabage characters
        Headline=re.sub(r'[,.;@#?!&$\-\']+', ' ', Headline, flags=re.IGNORECASE)
        Headline=re.sub(' +', ' ', Headline, flags=re.IGNORECASE)
        Headline=re.sub(r'\"', ' ', Headline, flags=re.IGNORECASE)
        Headline=re.sub(r'[^a-zA-Z0-9]', " ", Headline, flags=re.VERBOSE)
        ## Be sure there are no commas in the headlines or it will
        ## write poorly to a csv file....
        Headline=Headline.replace(',', '')
        Headline=' '.join(Headline.split())
        Headline=re.sub("\n|\r", "", Headline)
    
        print(Headline)



        #write to the csv file
        WriteThis=str(LABEL)+","+str(Date)+","+str(Source)+","+ str(Title) + "," + str(Headline) + "\n"
        print(WriteThis)
        
        #write to the csv file
        MyFILE.write(WriteThis)
        
    ## CLOSE THE CSV FILE
    MyFILE.close()
    ################## END for loop for newsapi.org #############################


 
    ## Open the NewsApi csv file for append and loop through articles
    MyFILE=open(filename, "a")
    for items in jsontxt2["results"]:
        
        counter2 = counter2 + 1
        if(counter2 > MaxArticles):
            break #limit the number of articles to no more than MaxArticles

        print(items, "\n\n\n")
                  
        Source=items["source_id"]
        print(Source)
        
        Date=items["pubDate"]
        ##clean up the date
        NewDate=Date.split(" ")
        Date=NewDate[0]
        print(Date)
        
        ## CLEAN the Title
        ##----------------------------------------------------------
        ##Replace punctuation with space
        # Accept one or more copies of punctuation         
        # plus zero or more copies of a space
        # and replace it with a single space
        Title=items["title"]
        Title=str(Title)
        Title=re.sub(r'[,.;@#?!&$\-\']+', ' ', str(Title), flags=re.IGNORECASE)
        Title=re.sub(' +', ' ', str(Title), flags=re.IGNORECASE)
        Title=re.sub(r'\"', ' ', str(Title), flags=re.IGNORECASE)
        print(Title)
        # and replace it with a single space
        ## NOTE: Using the "^" on the inside of the [] means
        ## we want to look for any chars NOT a-z or A-Z and replace
        ## them with blank. This removes chars that should not be there.
        Title=re.sub(r'[^a-zA-Z0-9]', " ", str(Title), flags=re.VERBOSE)
        Title=Title.replace(',', '')
        Title=' '.join(Title.split())
        Title=re.sub("\n|\r", "", Title)


        #clean up description
        Headline=items["description"]
        Headline=str(Headline)
        #remove grabage characters
        Headline=re.sub(r'[,.;@#?!&$\-\']+', ' ', Headline, flags=re.IGNORECASE)
        Headline=re.sub(' +', ' ', Headline, flags=re.IGNORECASE)
        Headline=re.sub(r'\"', ' ', Headline, flags=re.IGNORECASE)
        Headline=re.sub(r'[^a-zA-Z0-9]', " ", Headline, flags=re.VERBOSE)
        ## Be sure there are no commas in the headlines or it will
        ## write poorly to a csv file....
        Headline=Headline.replace(',', '')
        Headline=' '.join(Headline.split())
        Headline=re.sub("\n|\r", "", Headline)
    
        print(Headline)


        #write to the csv file
        WriteThis=str(LABEL)+","+str(Date)+","+str(Source)+","+ str(Title) + "," + str(Headline) +  "\n"
        print(WriteThis)
        
        #write to the csv file
        MyFILE.write(WriteThis)
        
    ## CLOSE THE CSV FILE
    MyFILE.close()
    ################## END for loop for newsdata.io #############################
    
################## END for loop for topics



#########################################################################################
##
##  Build labeled dataframes
##  convert the .csv file into labeled dataframes
##  use CountVectorixer and TfidfVectorizer
##
#########################################################################################

My_DF=pd.read_csv(filename, error_bad_lines=False)

## REMOVE any rows with NaN in them
My_DF = My_DF.dropna()

## Create the list of descriptions and labels
DescriptionLIST=[]
LabelLIST=[]

for nexthead, nextlabel in zip(My_DF["Description"], My_DF["LABEL"]):
    DescriptionLIST.append(nexthead)
    LabelLIST.append(nextlabel)


##########################################
## Remove all words that match the topics.

NewDescriptionLIST=[]

for element in DescriptionLIST:
    ## make into list
    AllWords=element.split(" ")
    ## Now remove words that are in your topics
    NewWordsList=[]
    for word in AllWords:
        word=word.lower()
        if word not in topics:
            NewWordsList.append(word)
            
    ##turn back to string
    NewWords=" ".join(NewWordsList)
    ## Place into NewDescriptionLIST
    NewDescriptionLIST.append(NewWords)

## Set the DescriptionLIST to the new one
DescriptionLIST=NewDescriptionLIST
        
# remove all words smaller than 4 characters and larger than 10 characters
CleanedDescriptionLIST = []
for Headline in DescriptionLIST:
    Headline=str(Headline)
    Headline = ' '.join([wd for wd in Headline.split() if len(wd)>3 and len(wd)<11])
    CleanedDescriptionLIST.append(Headline)


        
# remove all words containing numbers
CleanedDescriptionLIST2 = []
for Headline in CleanedDescriptionLIST:
    Headline=str(Headline)
    Headline = ' '.join([wd for wd in Headline.split() if not any(char.isdigit() for char in wd)])
    CleanedDescriptionLIST2.append(Headline)

#output to a csv file
print(CleanedDescriptionLIST2)
df = pd.DataFrame({'A':CleanedDescriptionLIST2})
df_split = df['A'].str.split(' ', expand=True)
df_split.to_csv("CleanedDescriptions.csv", header=False, index=False,)


### Tokenize and Vectorize the Descriptions

### Vectorize
## Instantiate CV
MyCountV=CountVectorizer(
                        input="content",
                        stop_words = "english",
                        max_df=0.5, 
                        min_df=0.01,
                        max_features=100
                        )

MyCVDTM = MyCountV.fit_transform(CleanedDescriptionLIST2)  # create a sparse matrix

ColumnNames=MyCountV.get_feature_names()

## Build the CV data frame
MyCV_DF=pd.DataFrame(MyCVDTM.toarray(),columns=ColumnNames)

#print and write to csv the unlabeled dataframe
print(MyCV_DF)
MyCV_DF.to_csv("Final_News_CV_DF_No_Labels.csv")

## Instantiate TFidf vectorizer
MyVect_TF=TfidfVectorizer(
                        input='content',
                        stop_words='english',
                        max_df=0.5, 
                        min_df=0.01,
                        max_features=100
                        )

MyTFDTM = MyVect_TF.fit_transform(CleanedDescriptionLIST2)  # create a sparse matrix

ColumnNames=MyVect_TF.get_feature_names()

## Build the TFidf data frame
MyTF_DF=pd.DataFrame(MyTFDTM.toarray(),columns=ColumnNames)

#print and write to csv the unlabeled dataframe
print(MyTF_DF)
MyTF_DF.to_csv("Final_News_TF_DF_No_Labels.csv")

#add labels
######################################################

## Convert the labels from list to df
Labels_DF = DataFrame(LabelLIST,columns=['LABEL'])

## Create a complete and labeled dataframe
CVdfs = [Labels_DF, MyCV_DF]
TFdfs = [Labels_DF, MyTF_DF]

Final_News_CV_DF_Labeled = pd.concat(CVdfs,axis=1, join='inner')
Final_News_TF_DF_Labeled = pd.concat(TFdfs,axis=1, join='inner')

#print and write to csv the final dataframe
print(Final_News_TF_DF_Labeled)
Final_News_TF_DF_Labeled.to_csv("Final_News_TF_DF_Labeled.csv")

print(Final_News_CV_DF_Labeled)
Final_News_CV_DF_Labeled.to_csv("Final_News_CV_DF_Labeled.csv")


#---------------------------------------------------------
##
## Use Stemming and Lemming
##
##---------------------------------------------------------

LEMMER = WordNetLemmatizer() 

STEMMER=PorterStemmer()

# Use NLTK's PorterStemmer in a function
def MY_STEMMER(str_input):
    words = re.sub(r"[^A-Za-z\-]", " ", str_input).lower().split()
    words = [STEMMER.stem(word) for word in words]
    return words

def MY_LEMMER(str_input):
    words = re.sub(r"[^A-Za-z\-]", " ", str_input).lower().split()
    words = [LEMMER.lemmatize(word) for word in words]
    return words

MyVect_STEM=CountVectorizer(
                        input='content',
                        analyzer = 'word',
                        stop_words='english',
                        tokenizer=MY_STEMMER,
                        max_df=0.5, 
                        min_df=0.01, 
                        max_features=100
                        )

Vect_Stem = MyVect_STEM.fit_transform(CleanedDescriptionLIST2)
ColumnNames_s=MyVect_STEM.get_feature_names()
CorpusDF_Stem=pd.DataFrame(Vect_Stem.toarray(),columns=ColumnNames_s)

#print and write to csv the unlabeled dataframe
print(CorpusDF_Stem)
CorpusDF_Stem.to_csv("Final_News_CV_STEM_No_Labels.csv")

MyVect_LEM=CountVectorizer(
                        input='content',
                        analyzer = 'word',
                        stop_words='english',
                        tokenizer=MY_LEMMER,
                        max_df=0.5, 
                        min_df=0.01, 
                        max_features=100
                        )


Vect_LEM = MyVect_LEM.fit_transform(CleanedDescriptionLIST2)
ColumnNames_lem=MyVect_LEM.get_feature_names()
CorpusDF_LEM=pd.DataFrame(Vect_LEM.toarray(),columns=ColumnNames_lem)

#print and write to csv the unlabeled dataframe
print(CorpusDF_LEM)
CorpusDF_LEM.to_csv("Final_News_CV_LEM_No_Labels.csv")

#add labels
######################################################

## Create a complete and labeled dataframe
STEMdfs = [Labels_DF, CorpusDF_Stem]
LEMdfs = [Labels_DF, CorpusDF_LEM]

Final_News_CV_STEM_Labeled = pd.concat(STEMdfs,axis=1, join='inner')
Final_News_CV_LEM_Labeled = pd.concat(LEMdfs,axis=1, join='inner')

#print and write to csv the final dataframe
print(Final_News_CV_STEM_Labeled)
Final_News_CV_STEM_Labeled.to_csv("Final_News_CV_STEM_Labeled.csv")

print(Final_News_CV_LEM_Labeled)
Final_News_CV_LEM_Labeled.to_csv("Final_News_CV_LEM_Labeled.csv")


## Create the word clouds for each  of the topics. 
##--------------------------------------------------------
List_of_WC_CV=[]
List_of_WC_LEM=[]

for mytopic in topics:

    #original CV DF
    tempdfCV = Final_News_CV_DF_Labeled[Final_News_CV_DF_Labeled['LABEL'] == mytopic]
    
    tempdfCV =tempdfCV.sum(axis=0,numeric_only=True)
    NextVarNameCV=str("wc"+str(mytopic))

    ## Create and store in a list the wordcloud OBJECTS
    NextVarNameCV = WordCloud(width=1000, height=600, background_color="white",
                   min_word_length=4, #mask=next_image,
                   max_words=200).generate_from_frequencies(tempdfCV)
    
    List_of_WC_CV.append(NextVarNameCV)


    #Lemmatized DF
    tempdfLEM = Final_News_CV_LEM_Labeled[Final_News_CV_LEM_Labeled['LABEL'] == mytopic]
    
    tempdfLEM =tempdfLEM.sum(axis=0,numeric_only=True)
    NextVarNameLEM=str("wc"+str(mytopic))

    ## Create and store in a list the wordcloud OBJECTS
    NextVarNameLEM = WordCloud(width=1000, height=600, background_color="white",
                   min_word_length=4, #mask=next_image,
                   max_words=200).generate_from_frequencies(tempdfLEM)
    
    List_of_WC_LEM.append(NextVarNameLEM)
    

##------------------------------------------------------------------

########## Create the wordclouds
##########
fig1=plt.figure(figsize=(25, 25))
NumTopics=len(topics)
for i in range(NumTopics):
    print(i)
    ax = fig1.add_subplot(NumTopics,1,i+1)
    plt.imshow(List_of_WC_CV[i], interpolation='bilinear')
    plt.axis("off")
    plt.savefig("WordCloudCV.pdf")

fig2=plt.figure(figsize=(25, 25))
for i in range(NumTopics):
    print(i)
    ax = fig2.add_subplot(NumTopics,1,i+1)
    plt.imshow(List_of_WC_LEM[i], interpolation='bilinear')
    plt.axis("off")
    plt.savefig("WordCloudLEM.pdf")
 
    



###############################################################
##
##               Model with two ML supervised options
##
##               DT
##               NB (multinomial)
##      
###############################################################         
## STEP 1   Create Training and Testing Data
###############################################################

TrainDF, TestDF = train_test_split(Final_News_CV_STEM_Labeled, test_size=0.3)
print(TrainDF)
print(TestDF)

#################################################
## STEP 2: Separate LABELS
#################################################
## IMPORTANT - YOU CANNOT LEAVE LABELS ON 
## Save labels

### TEST ---------------------
TestLabels=TestDF["LABEL"]
print(TestLabels)
TestDF = TestDF.drop(["LABEL"], axis=1)
print(TestDF)
### TRAIN----------------------
TrainLabels=TrainDF["LABEL"]
print(TrainLabels)
## remove labels
TrainDF = TrainDF.drop(["LABEL"], axis=1)

##################################################
## STEP 3:  Run MNB
##################################################

## Instantiate
MyModelNB= MultinomialNB()

## FIT
MyNB=MyModelNB.fit(TrainDF, TrainLabels)
print(MyNB.classes_)
print(MyNB.class_count_)
print(MyNB.feature_log_prob_)


Prediction = MyModelNB.predict(TestDF)
print(np.round(MyModelNB.predict_proba(TestDF),2))

## Confusion Matrix Accuracies
cnf_matrix = confusion_matrix(TestLabels, Prediction)
print("\nThe MNB confusion matrix is:")
print(cnf_matrix)


##################################################
## STEP 3:  Run DT
##################################################

## Tree 1: Entropy, best splitter
MyDT_entropy_best=DecisionTreeClassifier(criterion='entropy', ##"entropy" or "gini"
                            splitter='best',  ## or "random" or "best"
                            max_depth=None, 
                            min_samples_split=2, 
                            min_samples_leaf=1, 
                            min_weight_fraction_leaf=0.0, 
                            max_features=None, 
                            random_state=None, 
                            max_leaf_nodes=None, 
                            min_impurity_decrease=0.0, 
                            min_impurity_split=None, 
                            class_weight=None)

##
## Tree 2: Gini, best splitter
MyDT_gini_best=DecisionTreeClassifier(criterion='gini', ##"entropy" or "gini"
                            splitter='best',  ## or "random" or "best"
                            max_depth=None, 
                            min_samples_split=2, 
                            min_samples_leaf=1, 
                            min_weight_fraction_leaf=0.0, 
                            max_features=None, 
                            random_state=None, 
                            max_leaf_nodes=None, 
                            min_impurity_decrease=0.0, 
                            min_impurity_split=None, 
                            class_weight=None)

##

## Tree 3: Entropy, random splitter
MyDT_entropy_random=DecisionTreeClassifier(criterion='entropy', ##"entropy" or "gini"
                            splitter='random',  ## or "random" or "best"
                            max_depth=None, 
                            min_samples_split=2, 
                            min_samples_leaf=1, 
                            min_weight_fraction_leaf=0.0, 
                            max_features=None, 
                            random_state=None, 
                            max_leaf_nodes=None, 
                            min_impurity_decrease=0.0, 
                            min_impurity_split=None, 
                            class_weight=None)

##

#fit data
MyDT_entropy_best.fit(TrainDF, TrainLabels)
MyDT_gini_best.fit(TrainDF, TrainLabels)
MyDT_entropy_random.fit(TrainDF, TrainLabels)

#plot trees
feature_names=TrainDF.columns

#tree 1
fig3=plt.figure(figsize=(25, 25))
tree.plot_tree(MyDT_entropy_best)
plt.savefig("MyDT_entropy_best.pdf")

Tree_Object = tree.export_graphviz(MyDT_entropy_best, out_file=None,
                      feature_names=feature_names,  
                      class_names=topics,
                      filled=True, rounded=True,  
                      special_characters=True)      
                              
graph = graphviz.Source(Tree_Object)     
graph.render("MyTree_entropy_best") 

#tree 2
fig4=plt.figure(figsize=(25, 25))
tree.plot_tree(MyDT_gini_best)
plt.savefig("MyDT_gini_best.pdf")

Tree_Object = tree.export_graphviz(MyDT_gini_best, out_file=None,
                      feature_names=feature_names,  
                      class_names=topics,
                      filled=True, rounded=True,  
                      special_characters=True)      
                              
graph = graphviz.Source(Tree_Object)     
graph.render("MyTree_gini_best") 

#tree 3
fig5=plt.figure(figsize=(25, 25))
tree.plot_tree(MyDT_entropy_random)
plt.savefig("MyDT_entropy_random.pdf")

feature_names=TrainDF.columns
Tree_Object = tree.export_graphviz(MyDT_entropy_random, out_file=None,
                      feature_names=feature_names,  
                      class_names=topics,
                      filled=True, rounded=True,  
                      special_characters=True)      
                              
graph = graphviz.Source(Tree_Object)     
graph.render("MyTree_entropy_random") 


## Confusion Matrix

#tree 1
print("Prediction for tree 1 (entropy, best) is:\n")
DT_pred=MyDT_entropy_best.predict(TestDF)
print(DT_pred)
bn_matrix = confusion_matrix(TestLabels, DT_pred)
print("\nThe confusion matrix for tree 1 (entropy, best) is:")
print(bn_matrix)

#tree 2
print("Prediction for tree 2 (gini, best) is:\n")
DT_pred=MyDT_gini_best.predict(TestDF)
print(DT_pred)
bn_matrix = confusion_matrix(TestLabels, DT_pred)
print("\nThe confusion matrix for tree 2 (gini, best) is:")
print(bn_matrix)

#tree 3
print("Prediction for tree 3 (entropy, random) is:\n")
DT_pred=MyDT_entropy_random.predict(TestDF)
print(DT_pred)
bn_matrix = confusion_matrix(TestLabels, DT_pred)
print("\nThe confusion matrix for tree 3 (entropy, random) is:")
print(bn_matrix)

## print out the important features

#tree 1
print("\nTree 1:\n")
FeatureImp=MyDT_entropy_best.feature_importances_   
indices = np.argsort(FeatureImp)[::-1]

for f in range(TrainDF.shape[1]):
    if FeatureImp[indices[f]] > 0:
        print("%d. feature %d (%f)" % (f + 1, indices[f], FeatureImp[indices[f]]))
        print ("feature name: ", feature_names[indices[f]])

#tree 2
print("\nTree 2:\n")
FeatureImp=MyDT_gini_best.feature_importances_   
indices = np.argsort(FeatureImp)[::-1]

for f in range(TrainDF.shape[1]):
    if FeatureImp[indices[f]] > 0:
        print("%d. feature %d (%f)" % (f + 1, indices[f], FeatureImp[indices[f]]))
        print ("feature name: ", feature_names[indices[f]])

#tree 3
print("\nTree 3:\n")
FeatureImp=MyDT_entropy_random.feature_importances_   
indices = np.argsort(FeatureImp)[::-1]

for f in range(TrainDF.shape[1]):
    if FeatureImp[indices[f]] > 0:
        print("%d. feature %d (%f)" % (f + 1, indices[f], FeatureImp[indices[f]]))
        print ("feature name: ", feature_names[indices[f]])
        

#############################################
###########  SVM ############################
#############################################

#Linear
SVM_Model=LinearSVC(C=10)
SVM_Model.fit(TrainDF, TrainLabels)
print("SVM Linear Model prediction (C=10):\n", SVM_Model.predict(TestDF))
print("Actual:")
print(TestLabels)

SVM_matrix = confusion_matrix(TestLabels, SVM_Model.predict(TestDF))
print("\nThe confusion matrix for basic linear SVM (C=10) is:")
print(SVM_matrix)
print("\n\n")

SVM_Model=LinearSVC(C=50)
SVM_Model.fit(TrainDF, TrainLabels)
print("SVM Linear Model prediction (C=50):\n", SVM_Model.predict(TestDF))
print("Actual:")
print(TestLabels)

SVM_matrix = confusion_matrix(TestLabels, SVM_Model.predict(TestDF))
print("\nThe confusion matrix for basic linear SVM (C=50) is:")
print(SVM_matrix)
print("\n\n")

#RBF
SVM_Model==sklearn.svm.SVC(C=10, kernel='rbf', 
                           verbose=True, gamma="auto")
SVM_Model.fit(TrainDF, TrainLabels)
print("SVM RBF Model prediction (C=50):\n", SVM_Model.predict(TestDF))
print("Actual:")
print(TestLabels)

SVM_matrix = confusion_matrix(TestLabels, SVM_Model.predict(TestDF))
print("\nThe confusion matrix for RBF SVM (C=10) is:")
print(SVM_matrix)
print("\n\n")

SVM_Model==sklearn.svm.SVC(C=50, kernel='rbf', 
                           verbose=True, gamma="auto")
SVM_Model.fit(TrainDF, TrainLabels)
print("SVM RBF Model prediction (C=50):\n", SVM_Model.predict(TestDF))
print("Actual:")
print(TestLabels)

SVM_matrix = confusion_matrix(TestLabels, SVM_Model.predict(TestDF))
print("\nThe confusion matrix for RBF SVM (C=50) is:")
print(SVM_matrix)
print("\n\n")


#Polynomial
SVM_Model=sklearn.svm.SVC(C=10, kernel='poly',degree=3,
                           gamma="auto", verbose=True)
SVM_Model.fit(TrainDF, TrainLabels)
print("SVM Polynomial Model prediction (C=50):\n", SVM_Model.predict(TestDF))
print("Actual:")
print(TestLabels)

SVM_matrix = confusion_matrix(TestLabels, SVM_Model.predict(TestDF))
print("\nThe confusion matrix for polynomial SVM (C=10) is:")
print(SVM_matrix)
print("\n\n")

SVM_Model=sklearn.svm.SVC(C=50, kernel='poly',degree=3,
                           gamma="auto", verbose=True)
SVM_Model.fit(TrainDF, TrainLabels)
print("SVM Polynomial Model prediction (C=50):\n", SVM_Model.predict(TestDF))
print("Actual:")
print(TestLabels)

SVM_matrix = confusion_matrix(TestLabels, SVM_Model.predict(TestDF))
print("\nThe confusion matrix for polynomial SVM (C=50) is:")
print(SVM_matrix)
print("\n\n")
###############################################################
##
##   Visualizing the top 20 features for each of the 4 classes
##
###############################################################

## Credit: https://medium.com/@aneesha/visualising-top-features-in-linear-svm-with-scikit-learn-and-matplotlib-3454ab18a14d
## Define a function to visualize the TOP words (variables)
SVM_Model=LinearSVC(C=10)
SVM_Model.fit(TrainDF, TrainLabels)
score = SVM_Model.score(TrainDF, TrainLabels)
print("SVM_Model Score: ", score)

def plot_coefficients2(MODEL=SVM_Model, COLNAMES=TrainDF.columns, top_features=20, num_classes=4):
    for i in range(num_classes):
        coef = MODEL.coef_[i,:]
        top_positive_coefficients = np.argsort(coef,axis=0)[-top_features:]
        top_negative_coefficients = np.argsort(coef,axis=0)[:top_features]
        top_coefficients = np.hstack([top_negative_coefficients, top_positive_coefficients])

        # create plot
        plt.figure(figsize=(15, 6))
        feature_names = np.array(COLNAMES)

        colors = ["red" if c < 0 else "blue" for c in coef[top_coefficients]]
        plt.bar(  x=  np.arange(2 * top_features)  , height=coef[top_coefficients], width=.5,  color=colors)
        plt.xticks(np.arange(0, (2*top_features)), feature_names[top_coefficients], rotation=60, ha="right")
        
        fname = "KeyWords_class"+str(i)+".pdf"
        plt.savefig(fname)
        plt.show()
    

plot_coefficients2()

print("\nDone!") 


