########################################

## Module 3
##
## Topics: Sentoment classification with SVM

# much of the code was patterned after Dr. Gates' tutorials located at https://gatesboltonanalytics.com/
#########################################    

## What to import
import csv
import requests  ## for getting data from a server GET
import re   ## for regular expressions
import pandas as pd    ## for dataframes and related
from pandas import DataFrame

## To tokenize and vectorize text type data
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np

#word clouds
from wordcloud import WordCloud, STOPWORDS
import matplotlib.pyplot as plt

#stemming and lemming
from nltk.stem import WordNetLemmatizer 
from nltk.stem.porter import PorterStemmer

import matplotlib.pyplot as plt
import numpy as np

#clustering, SVM, DT, MNB
from sklearn.metrics import silhouette_samples, silhouette_score
import sklearn

from sklearn import preprocessing
from sklearn.preprocessing import LabelBinarizer

import seaborn as sns
from sklearn.metrics.pairwise import euclidean_distances
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.manifold import MDS
from mpl_toolkits.mplot3d import Axes3D
from scipy.cluster.hierarchy import ward, dendrogram

from sklearn.model_selection import train_test_split
import random as rd
from sklearn.metrics import confusion_matrix
from sklearn.svm import LinearSVC


topics=["cashless", "cashless society", "virtual currency", "virtual money"]

###############################################################
##
##  Train SVM on the sentiment labeled data
##
###############################################################

STEMMER=PorterStemmer()

# Use NLTK's PorterStemmer in a function
def MY_STEMMER(str_input):
    words = re.sub(r"[^A-Za-z\-]", " ", str_input).lower().split()
    words = [STEMMER.stem(word) for word in words]
    return words


My_DF=pd.read_csv("NewsDataApi_with_Sentiment_Labels.csv", error_bad_lines=False)

## REMOVE any rows with NaN in them
My_DF = My_DF.dropna()

## Create the list of descriptions and labels
DescriptionLIST=[]
LabelLIST=[]

for nexthead, nextlabel in zip(My_DF["Description"], My_DF["Sentiment"]):
    DescriptionLIST.append(nexthead)
    LabelLIST.append(nextlabel)


##########################################
## Remove all words that match the topics.

NewDescriptionLIST=[]

for element in DescriptionLIST:
    ## make into list
    AllWords=element.split(" ")
    ## Now remove words that are in your topics
    NewWordsList=[]
    for word in AllWords:
        word=word.lower()
        if word not in topics:
            NewWordsList.append(word)
            
    ##turn back to string
    NewWords=" ".join(NewWordsList)
    ## Place into NewDescriptionLIST
    NewDescriptionLIST.append(NewWords)

## Set the DescriptionLIST to the new one
DescriptionLIST=NewDescriptionLIST
        
# remove all words smaller than 4 characters and larger than 10 characters
CleanedDescriptionLIST = []
for Headline in DescriptionLIST:
    Headline=str(Headline)
    Headline = ' '.join([wd for wd in Headline.split() if len(wd)>3 and len(wd)<11])
    CleanedDescriptionLIST.append(Headline)

# remove all words containing numbers
CleanedDescriptionLIST2 = []
for Headline in CleanedDescriptionLIST:
    Headline=str(Headline)
    Headline = ' '.join([wd for wd in Headline.split() if not any(char.isdigit() for char in wd)])
    CleanedDescriptionLIST2.append(Headline)

#vectorize
MyVect_STEM=CountVectorizer(
                        input='content',
                        analyzer = 'word',
                        stop_words='english',
                        tokenizer=MY_STEMMER,
                        max_df=0.5, 
                        min_df=0.01, 
                        max_features=100
                        )

Vect_Stem = MyVect_STEM.fit_transform(CleanedDescriptionLIST2)
ColumnNames_s=MyVect_STEM.get_feature_names()
CorpusDF_Stem=pd.DataFrame(Vect_Stem.toarray(),columns=ColumnNames_s)

#add labels
######################################################

## Convert the labels from list to df
Labels_DF = DataFrame(LabelLIST,columns=['Sentiment'])


## Create a complete and labeled dataframe
STEMdfs = [Labels_DF, CorpusDF_Stem]
Final_News_CV_STEM_Labeled = pd.concat(STEMdfs,axis=1, join='inner')

print(Final_News_CV_STEM_Labeled)

###############################################################         
## STEP 1   Create Training and Testing Data
###############################################################

TrainDF, TestDF = train_test_split(Final_News_CV_STEM_Labeled, test_size=0.3)
print(TrainDF)
print(TestDF)

#################################################
## STEP 2: Separate LABELS
#################################################
## IMPORTANT - YOU CANNOT LEAVE LABELS ON 
## Save labels

### TEST ---------------------
TestLabels=TestDF["Sentiment"]
print(TestLabels)
TestDF = TestDF.drop(["Sentiment"], axis=1)
print(TestDF)
### TRAIN----------------------
TrainLabels=TrainDF["Sentiment"]
print(TrainLabels)
## remove labels
TrainDF = TrainDF.drop(["Sentiment"], axis=1)

##################################################
## STEP 3:  Run SVM
##################################################

#Linear
SVM_Model=LinearSVC(C=10)
SVM_Model.fit(TrainDF, TrainLabels)
print("SVM Linear Model prediction (C=10):\n", SVM_Model.predict(TestDF))
print("Actual:")
print(TestLabels)
print("\nDone!") 

SVM_matrix = confusion_matrix(TestLabels, SVM_Model.predict(TestDF))
print("\nThe confusion matrix for basic linear SVM (C=10) is:")
print(SVM_matrix)
print("\n\n")

###############################################################
##
##   Visualizing the top 20 features for each of the 3 classes
##
###############################################################

## Credit: https://medium.com/@aneesha/visualising-top-features-in-linear-svm-with-scikit-learn-and-matplotlib-3454ab18a14d
## Define a function to visualize the TOP words (variables)
SVM_Model=LinearSVC(C=10)
SVM_Model.fit(TrainDF, TrainLabels)
score = SVM_Model.score(TrainDF, TrainLabels)
print("SVM_Model Score: ", score)

def plot_coefficients2(MODEL=SVM_Model, COLNAMES=TrainDF.columns, top_features=20, num_classes=3):
    for i in range(num_classes):
        coef = MODEL.coef_[i,:]
        top_positive_coefficients = np.argsort(coef,axis=0)[-top_features:]
        top_negative_coefficients = np.argsort(coef,axis=0)[:top_features]
        top_coefficients = np.hstack([top_negative_coefficients, top_positive_coefficients])

        # create plot
        plt.figure(figsize=(15, 6))
        feature_names = np.array(COLNAMES)

        colors = ["red" if c < 0 else "blue" for c in coef[top_coefficients]]
        plt.bar(  x=  np.arange(2 * top_features)  , height=coef[top_coefficients], width=.5,  color=colors)
        plt.xticks(np.arange(0, (2*top_features)), feature_names[top_coefficients], rotation=60, ha="right")
        
        fname = "KeyWords_class"+str(i)+".pdf"
        plt.savefig(fname)
        plt.show()
    

plot_coefficients2()

print("\nDone!") 



