## NN - FF and BP
## Gates

#############################################
## NN with FF - BP for Sentiment Labeled data
## Labels: 0 and 1 where 0 is negative and 1 is positive or neutral
## Data is 100D
        
#####################################################     
import csv
import re   ## for regular expressions
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix
from pandas import DataFrame

## To tokenize and vectorize text type data
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer

#stemming and lemming
from nltk.stem import WordNetLemmatizer 
from nltk.stem.porter import PorterStemmer

from sklearn.model_selection import train_test_split

MAX_FEATURES = 100

# topics to query
topics=["cashless", "cashless society", "virtual currency", "virtual money"]
###############################################################
##
##  Train NN on the sentiment labeled data
##
###############################################################

STEMMER=PorterStemmer()

# Use NLTK's PorterStemmer in a function
def MY_STEMMER(str_input):
    words = re.sub(r"[^A-Za-z\-]", " ", str_input).lower().split()
    words = [STEMMER.stem(word) for word in words]
    return words


My_DF=pd.read_csv("NewsDataApi_with_Sentiment_Labels.csv", error_bad_lines=False)

## REMOVE any rows with NaN in them
My_DF = My_DF.dropna()

## Create the list of descriptions and labels
DescriptionLIST=[]
LabelLIST=[]

for nexthead, nextlabel in zip(My_DF["Description"], My_DF["Sentiment"]):
    DescriptionLIST.append(nexthead)
    LabelLIST.append(nextlabel)


##########################################
## Remove all words that match the topics.

NewDescriptionLIST=[]

for element in DescriptionLIST:
    ## make into list
    AllWords=element.split(" ")
    ## Now remove words that are in your topics
    NewWordsList=[]
    for word in AllWords:
        word=word.lower()
        if word not in topics:
            NewWordsList.append(word)
            
    ##turn back to string
    NewWords=" ".join(NewWordsList)
    ## Place into NewDescriptionLIST
    NewDescriptionLIST.append(NewWords)

## Set the DescriptionLIST to the new one
DescriptionLIST=NewDescriptionLIST
        
# remove all words smaller than 4 characters and larger than 10 characters
CleanedDescriptionLIST = []
for Headline in DescriptionLIST:
    Headline=str(Headline)
    Headline = ' '.join([wd for wd in Headline.split() if len(wd)>3 and len(wd)<11])
    CleanedDescriptionLIST.append(Headline)

# remove all words containing numbers
CleanedDescriptionLIST2 = []
for Headline in CleanedDescriptionLIST:
    Headline=str(Headline)
    Headline = ' '.join([wd for wd in Headline.split() if not any(char.isdigit() for char in wd)])
    CleanedDescriptionLIST2.append(Headline)

#vectorize
MyVect_STEM=TfidfVectorizer(
                        input='content',
                        analyzer = 'word',
                        stop_words='english',
                        tokenizer=MY_STEMMER,
                        max_df=0.5, 
                        min_df=0.01,
                        max_features=MAX_FEATURES
                        )


Vect_Stem = MyVect_STEM.fit_transform(CleanedDescriptionLIST2)
ColumnNames_s=MyVect_STEM.get_feature_names()
CorpusDF_Stem=pd.DataFrame(Vect_Stem.toarray(),columns=ColumnNames_s)

#add labels
######################################################

## Convert the labels from list to df
Labels_DF = DataFrame(LabelLIST,columns=['Sentiment'])


## Create a complete and labeled dataframe
STEMdfs = [Labels_DF, CorpusDF_Stem]
Final_News_TFDF_STEM_Labeled = pd.concat(STEMdfs,axis=1, join='inner')

print(Final_News_TFDF_STEM_Labeled)
Final_News_TFDF_STEM_Labeled.to_csv("Final_News_with_Sentiment_Labels_TFDF_STEM_Labeled.csv", index=False)

###############################################################         
## STEP 1   Create Training and Testing Data
###############################################################

DF_train, DF_test = train_test_split(Final_News_TFDF_STEM_Labeled, test_size=0.3)
print(DF_train)
print(DF_test)
DF_train.to_csv("Train_Final_News_with_Sentiment_Labels_TFDF_STEM_Labeled.csv", index=False)
DF_test.to_csv("Test_Final_News_with_Sentiment_Labels_TFDF_STEM_Labeled.csv", index=False)


#set up the training data
#########################
## Set y to the label. Check the shape!
y = np.array(DF_train.iloc[:,100]).T
y = np.array([y]).T
print("y is\n", y)
#update labels so that they're 0 (if y is negative) or 1 (if y is positive or neutral)
y = np.where(y == "negative", 0, 1)
print("binary y is\n", y)

X = DF_train.iloc[:,1:100]
print("X is\n", X)
## No need to normalize the data (it's been already normalized through tfidf)
X = np.array(X)
print("Normalized X is\n", X)

#set up the test data
#####################
## Set y to the label. Check the shape!
y_test = np.array(DF_test.iloc[:,100]).T
y_test = np.array([y_test]).T
print("y_test is\n", y_test)
#update labels so that they're 0 (if y is negative) or 1 (if y is positive or neutral)
y_test = np.where(y_test == "negative", 0, 1)
print("binary y_test is\n", y_test)

X_test = DF_test.iloc[:,1:100]
print("X_test is\n", X_test)
## No need to normalize the data (it's been already normalized through tfidf)
X_test = np.array(X_test)
print("Normalized X_test is\n", X_test)

InputColumns = 100
n = len(X) ## number of rows of entire X

LR = .001
LRB = .001
#................................................
 

class NeuralNetwork(object):
    def __init__(self):
        
        self.InputNumColumns = InputColumns  ## columns
        self.OutputSize = 1 ## Categories
        self.HiddenUnits = 16  ## one layer with h units
        self.n = n  ## number of training examples, n
        
        #print("Initialize NN\n")
        #Random W1
        self.W1 = np.random.randn(self.InputNumColumns, self.HiddenUnits) # c by h  
       
        #print("INIT W1 is\n", self.W1)
        
        ##-----------------------------------------
        ## NOTE ##
        ##
        ## The following are all random. However, you can comment this out
        ## and can set any weights and biases by hand , etc.
        ##
        ##---------------------------------------------
        
        self.W2 = np.random.randn(self.HiddenUnits, self.OutputSize) # h by o 
        #print("W2 is:\n", self.W2)
        
        self.b = np.random.randn(1, self.HiddenUnits)
        #print("The b's are:\n", self.b)
        ## biases for layer 1
        
        self.c = np.random.randn(1, self.OutputSize)
        #print("The c is\n", self.c)
        ## bias for last layer
        
        
    def FeedForward(self, X):
        #print("FeedForward\n\n")
        self.z = (np.dot(X, self.W1)) + self.b 
        #X is n by c   W1  is c by h -->  n by h
        #print("Z1 is:\n", self.z)
        
        self.h = self.Sigmoid(self.z) #activation function    shape: n by h
        #print("H is:\n", self.h)
        
        self.z2 = (np.dot(self.h, self.W2)) + self.c # n by h  @  h by o  -->  n by o  
        #print("Z2 is:\n", self.z2)
        
        ## Using Softmax for the output activation
        output = self.Sigmoid(self.z2)  
        #print("output Y^ is:\n", output)
        return output
        
    def Sigmoid(self, s, deriv=False):
        if (deriv == True):
            return s * (1 - s)
        return 1/(1 + np.exp(-s))
    
    def BackProp(self, X, y, output):
        #print("\n\nBackProp\n")
        self.LR = LR
        self.LRB=LRB  ## LR for biases
        
        # Y^ - Y
        self.output_error = output - y    
        #print("Y^ - Y\n", self.output_error)
        
        ## NOTE TO READER........................
        ## Here - we DO NOT multiply by derivative of Sig for y^ b/c we are using 
        ## cross entropy and softmax for the loss and last activation
        # REMOVED # self.output_delta = self.output_error * self.Sigmoid(output, deriv=True) 
        ## So the above line is commented out...............
        
        self.output_delta = self.output_error 
          
        ##(Y^ - Y)(W2)
        self.D_Error_W2 = self.output_delta.dot(self.W2.T) #  D_Error times W2
        #print("W2 is\n", self.W2)
        #print(" D_Error times W2\n", self.D_Error_W2)
        
        ## (H)(1 - H) (Y^ - Y)(Y^)(1-Y^)(W2)
        ## We still use the Sigmoid on H
        
        self.H_D_Error_W2 = self.D_Error_W2 * self.Sigmoid(self.h, deriv=True) 
        
        ## Note that * will multiply respective values together in each matrix
        #print("Derivative sig H is:\n", self.Sigmoid(self.h, deriv=True))
        #print("self.H_D_Error_W2 is\n", self.H_D_Error_W2)
        
        ################------UPDATE weights and biases ------------------
        #print("Old W1: \n", self.W1)
        #print("Old W2 is:\n", self.W2)
        #print("X transpose is\n", X.T)
        
        ##  XT  (H)(1 - H) (Y^ - Y)(Y^)(1-Y^)(W2)
        self.X_H_D_Error_W2 = X.T.dot(self.H_D_Error_W2) ## this is dW1
        
        ## (H)T (Y^ - Y) - 
        self.h_output_delta = self.h.T.dot(self.output_delta) ## this is for dW2
        
        #print("the gradient :\n", self.X_H_D_Error_W2)
        #print("the gradient average:\n", self.X_H_D_Error_W2/self.n)
        
        #print("Using sum gradient........\n")
        self.W1 = self.W1 - self.LR*(self.X_H_D_Error_W2) # c by h  adjusting first set (input -> hidden) weights
        self.W2 = self.W2 - self.LR*(self.h_output_delta) 
        
        
        #print("The sum of the b update is\n", np.mean(self.H_D_Error_W2, axis=0))
        #print("The b biases before the update are:\n", self.b)
        self.b = self.b  - self.LRB*np.mean(self.H_D_Error_W2, axis=0)
        #print("The H_D_Error_W2 is...\n", self.H_D_Error_W2)
        #print("Updated bs are:\n", self.b)
        
        self.c = self.c - self.LR*np.mean(self.output_delta, axis=0)
        #print("Updated c's are:\n", self.c)
        
        #print("The W1 is: \n", self.W1)
        #print("The W1 gradient is: \n", self.X_H_D_Error_W2)
        #print("The W1 gradient average is: \n", self.X_H_D_Error_W2/self.n)
        #print("The W2 gradient  is: \n", self.h_output_delta)
        #print("The W2 gradient average is: \n", self.h_output_delta/self.n)
        #print("The biases b gradient is:\n",np.mean(self.H_D_Error_W2, axis=0 ))
        #print("The bias c gradient is: \n", np.mean(self.output_delta, axis=0))
        ################################################################
        
    def TrainNetwork(self, X, y):
        output = self.FeedForward(X)
        #print("Output in TNN\n", output)
        self.BackProp(X, y, output)
        return output        
    
    def RunNetwork(self, X):
        output = self.FeedForward(X)
        #print("Output in TNN\n", output)
        return output

#-------------------------------------------------------------------        
MyNN = NeuralNetwork()

TotalLoss=[]
AvgLoss=[]
Epochs=10000

for i in range(Epochs): 
    print("RUN: ", i)
    output=MyNN.TrainNetwork(X, y)
   
    #print("The y is ...\n", y)
    #print("The output is: \n", output)
    output=np.where(output > 0.5, 1, 0)
    #print('Prediction y^ is', output)
    ## Using Categorical Cross Entropy...........
    #loss = np.mean(-y * np.log(output))  ## We need y to place the "1" in the right place
    loss=np.sum(np.square(output-y))
    avgLoss=np.mean(np.square(output-y))
    print("The current loss is\n", loss)
    print("The current average loss is\n", avgLoss)
    TotalLoss.append(loss)
    AvgLoss.append(avgLoss)


###################-output and vis----------------------    
import matplotlib.pyplot as plt

plt.plot(range(1, len(TotalLoss) + 1), TotalLoss)
plt.xlabel('Iterations')
plt.ylabel('Cost')
plt.title('Neural Network: 1 hidden layer with 16 nodes')
plt.show()

#run the trained network with the test data
output=MyNN.RunNetwork(X_test)
output=np.where(output > 0.5, 1, 0)
print("\nPredicted Label  True Label\n")
for i in range(0, len(y_test)):
    print("\t", output[i], "\t", y_test[i])
loss=np.sum(np.square(output-y_test))
avgLoss=np.mean(np.square(output-y_test))
print("The test loss is\n", loss)
print("The test average loss is\n", avgLoss)
print("\nConfusion Matrix:\n", confusion_matrix(output, y_test))
